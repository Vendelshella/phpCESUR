<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookies</title>
</head>
<body>
    <!-- Formulario para introducir el nombre del usuario -->
    <form action="pag2.php" method="post">
        <label for="user_name">Nombre: <input type="text" name="user_name"></label>
        <input type="submit" value="Enviar" name="send">
    </form>
</body>
</html>